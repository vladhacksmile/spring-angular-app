export class AuthLoginInfo {
  username: string;
  password: String;

  constructor(username: string, password: string) {
    this.username = username;
    this.password = password;
  }
}